#!/usr/bin/env bash
# Authored by: Shubham Tapadiya
# Created: 2026-09-02
# Updated: 2026-09-02
#
# One-time local dev setup: virtualenv + dependencies + .env.
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

if [ ! -d .venv ]; then
    python3 -m venv .venv
fi

source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt -r requirements-dev.txt

if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created .env from .env.example -- edit it for your environment."
fi

echo "Setup complete. Activate with: source .venv/bin/activate"
echo "Run the test suite with: pytest"
echo "For the ONNX/Kafka backends, also run: pip install -r requirements-ml.txt"
